import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
  meta: [
    { charSet: "utf-8" },
    { name: "viewport", content: "width=device-width, initial-scale=1" },
    { name: "robots", content: "index, follow" },
    { name: "author", content: "Cogniloop" },

    // Title & Description
    { title: "Cogniloop — Custom Software, AI & Digital Marketing" },
    { name: "description", content: "Cogniloop is a software house engineering custom platforms, AI systems, and growth-focused digital marketing for ambitious brands." },
    { name: "keywords", content: "custom software development, AI services, digital marketing, SaaS development, LLM apps, web development Pakistan" },

    // Open Graph
    { property: "og:type", content: "website" },
    { property: "og:url", content: "https://www.cogniloop.digital/" },
    { property: "og:title", content: "Cogniloop — Build. Think. Grow." },
    { property: "og:description", content: "Custom software, AI services and digital marketing under one roof." },
    { property: "og:image", content: "https://www.cogniloop.digital/og_image.jpg" },

    // Twitter
    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:site", content: "@cogniloop" },
    { name: "twitter:title", content: "Cogniloop — Build. Think. Grow." },
    { name: "twitter:description", content: "Custom software, AI services and digital marketing under one roof." },
    { name: "twitter:image", content: "https://www.cogniloop.digital/og_image.jpg" },

    // JSON-LD
    {
      "script:ld+json": {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "Cogniloop",
        "url": "https://www.cogniloop.digital",
        "logo": "https://www.cogniloop.digital/logo.jpg",
        "email": "info@cogniloop.digital",
        "foundingDate": "2019",
        "description": "Cogniloop is a software house engineering custom platforms, AI systems, and growth-focused digital marketing for ambitious brands.",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "PK"
        },
        "sameAs": [
          "https://www.linkedin.com/company/cogniloop",
          "https://facebook.com/share/18rLrh1s58/",
          "https://www.instagram.com/cogniloop.digital/"
        ],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": "Services",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Custom Software Development",
                "description": "Web, mobile and enterprise platforms engineered from first principles."
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "AI Services",
                "description": "Production-ready AI agents, LLM pipelines and computer vision systems."
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": "Digital Marketing",
                "description": "Performance-driven growth: SEO, paid acquisition and content."
              }
            }
          ]
        }
      }
    },
  ],
  links: [
    { rel: "stylesheet", href: appCss },
    { rel: "canonical", href: "https://www.cogniloop.digital/" },
    { rel: "icon", href: "/favicon.ico" },
    { rel: "shortcut icon", href: "/favicon.ico" },
    { rel: "apple-touch-icon", href: "/favicon.ico" },
    { rel: "preconnect", href: "https://fonts.googleapis.com" },
    { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
    {
      rel: "stylesheet",
      href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap",
    },
  ],
}),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
