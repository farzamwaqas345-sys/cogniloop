import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Code2, Cpu, Megaphone, Check, Zap } from "lucide-react";
import heroImg from "@/assets/hero.jpg";
import logoImg from "@/assets/logo.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
  meta: [
    { title: "Cogniloop — Custom Software, AI & Digital Marketing" },
    { name: "description", content: "Cogniloop is a software house engineering custom platforms, AI systems, and growth-focused digital marketing for ambitious brands." },
    { name: "keywords", content: "custom software development, AI services, digital marketing, SaaS development, LLM apps, web development Pakistan" },
    { name: "robots", content: "index, follow" },
    { name: "viewport", content: "width=device-width, initial-scale=1" },

    // Open Graph
    { property: "og:type", content: "website" },
    { property: "og:url", content: "https://www.cogniloop.digital/" },
    { property: "og:title", content: "Cogniloop — Build. Think. Grow." },
    { property: "og:description", content: "Custom software, AI services and digital marketing under one roof." },
    { property: "og:image", content: "https://www.cogniloop.digital/og_image.jpg" },

    // Twitter
    { name: "twitter:card", content: "summary_large_image" },
    { name: "twitter:title", content: "Cogniloop — Build. Think. Grow." },
    { name: "twitter:description", content: "Custom software, AI services and digital marketing under one roof." },
    { name: "twitter:image", content: "https://www.cogniloop.digital/og_image.jpg" },
  ],
  links: [
    { rel: "canonical", href: "https://www.cogniloop.digital/" },
  ],
}),
  component: Index,
});

const services = [
  {
    icon: Code2,
    tag: "01",
    title: "Custom Software",
    desc: "Web, mobile and enterprise platforms engineered from first principles — built to scale, designed to last.",
    points: ["SaaS & internal tools", "Cloud architecture", "API & systems integration"],
  },
  {
    icon: Cpu,
    tag: "02",
    title: "AI Services",
    desc: "Production-ready AI agents, LLM pipelines and computer vision systems that ship measurable business outcomes.",
    points: ["LLM apps & RAG", "AI automation", "Predictive models"],
  },
  {
    icon: Megaphone,
    tag: "03",
    title: "Digital Marketing",
    desc: "Performance-driven growth: brand, SEO, paid acquisition and content engineered around your funnel.",
    points: ["SEO & content", "Paid media", "Brand & creative"],
  },
];

const stats = [
  { value: "120+", label: "Projects shipped" },
  { value: "40+", label: "Enterprise clients" },
  { value: "9", label: "Countries served" },
  { value: "24/7", label: "Engineering support" },
];

const process = [
  { step: "Discover", desc: "We map your goals, users and constraints into a clear technical brief." },
  { step: "Design", desc: "Architecture, UX and interfaces — prototyped fast, validated faster." },
  { step: "Build", desc: "Tight engineering loops, weekly demos, production from day one." },
  { step: "Scale", desc: "Measure, optimize, and grow — with AI and marketing in lockstep." },
];

const clients = ["NORTHWIND", "ACME LABS", "ORBIT", "HELIX", "VANTA", "QUASAR", "NIMBUS", "PRISM"];

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <Hero />
      <Marquee />
      <Services />
      <Stats />
      <Process />
      <CTA />
      <Footer />
    </div>
  );
}

function Logo() {
  return (
    <a href="#top" className="flex items-center">
      <img src={logoImg} alt="Cogniloop" className="h-10 w-auto" />
    </a>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="container-x flex h-16 items-center justify-between">
        <Logo />
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#services" className="transition-colors hover:text-foreground">Services</a>
          <a href="#work" className="transition-colors hover:text-foreground">Work</a>
          <a href="#process" className="transition-colors hover:text-foreground">Process</a>
          <a href="#contact" className="transition-colors hover:text-foreground">Contact</a>
        </nav>
        <a
          href="#contact"
          className="group inline-flex items-center gap-1.5 rounded-sm bg-foreground px-4 py-2 text-sm font-medium text-background transition-transform hover:-translate-y-0.5"
        >
          Start a project
          <ArrowUpRight className="h-4 w-4 transition-transform group-hover:rotate-45" />
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-border">
      <div className="absolute inset-0 grid-bg opacity-60" aria-hidden />
      <div className="container-x relative grid gap-12 py-20 md:py-28 lg:grid-cols-12 lg:gap-8">
        <div className="lg:col-span-7">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-mono uppercase tracking-widest text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
            Est. 2019
          </div>
          <h1 className="text-balance text-5xl font-semibold leading-[0.95] tracking-tight md:text-7xl lg:text-[5.5rem]">
           End-to-end digital<br />
            <span className="relative inline-block">
              <span className="relative z-10 text-accent">solutions</span>
              <span className="absolute -bottom-1 left-0 h-2 w-full bg-accent/15" />
            </span>{" "}
            <br className="hidden md:block" />for ambitious brands.
          </h1>
          <p className="mt-8 max-w-xl text-balance text-lg text-muted-foreground">
            Cogniloop is a software house pairing custom engineering, applied AI, and digital marketing
            — so the product, the intelligence and the growth ship together.
          </p>
          <div className="mt-10 flex flex-wrap items-center gap-3">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-sm bg-accent px-6 py-3.5 text-sm font-medium text-accent-foreground shadow-[var(--shadow-red)] transition-transform hover:-translate-y-0.5"
            >
              Book a call
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:rotate-45" />
            </a>
            <a
              href="#services"
              className="inline-flex items-center gap-2 rounded-sm border border-border bg-card px-6 py-3.5 text-sm font-medium hover:bg-muted"
            >
              Explore services
            </a>
          </div>
          <div className="mt-12 flex items-center gap-6 font-mono text-xs uppercase tracking-widest text-muted-foreground">
            <span className="flex items-center gap-2"><Zap className="h-3 w-3 text-accent" /> Seamless Execution | Growth driven</span>
          </div>
        </div>
        <div className="relative lg:col-span-5">
          <div className="relative aspect-[4/5] overflow-hidden rounded-sm border border-border bg-card">
            <img
              src={heroImg}
              alt="Abstract geometric composition with red accents"
              width={1600}
              height={1200}
              className="h-full w-full object-cover"
            />
            <div className="absolute left-4 top-4 rounded-sm bg-background/90 px-3 py-1.5 font-mono text-[10px] uppercase tracking-widest backdrop-blur">
              ● Live · v.2026
            </div>
            <div className="absolute bottom-4 right-4 max-w-[14rem] rounded-sm bg-background/95 p-3 font-mono text-[11px] backdrop-blur">
              <div className="text-muted-foreground">// uptime</div>
              <div className="text-foreground">99% across 40+ systems</div>
            </div>
          </div>
          <div className="absolute -bottom-4 -left-4 hidden h-24 w-24 border-l-2 border-b-2 border-accent md:block" aria-hidden />
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  return (
    <section className="border-b border-border bg-card py-6 overflow-hidden">
      <div className="flex w-max marquee gap-16 whitespace-nowrap font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
        {[...clients, ...clients, ...clients, ...clients].map((c, i) => (
          <span key={i} className="flex items-center gap-16">
            {c}
            <span className="h-1 w-1 rounded-full bg-accent" />
          </span>
        ))}
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services" className="border-b border-border py-24 md:py-32">
      <div className="container-x">
        <div className="mb-16 flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <div className="mb-4 font-mono text-xs uppercase tracking-widest text-accent">— Services</div>
            <h2 className="text-balance text-4xl font-semibold tracking-tight md:text-5xl">
              Three disciplines. One outcome: <span className="text-muted-foreground">leverage.</span>
            </h2>
          </div>
          <p className="max-w-sm text-muted-foreground">
            Whether you need a product built, a model deployed, or a pipeline filled — we ship the
            full stack of growth.
          </p>
        </div>
        <div className="grid gap-px overflow-hidden rounded-sm border border-border bg-border md:grid-cols-3">
          {services.map((s) => {
            const Icon = s.icon;
            return (
              <article key={s.title} className="group relative flex flex-col bg-background p-8 transition-colors hover:bg-card">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs tracking-widest text-muted-foreground">{s.tag}</span>
                  <Icon className="h-5 w-5 text-accent" />
                </div>
                <h3 className="mt-10 text-2xl font-semibold">{s.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground">{s.desc}</p>
                <ul className="mt-6 space-y-2 text-sm">
                  {s.points.map((p) => (
                    <li key={p} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-accent" />
                      {p}
                    </li>
                  ))}
                </ul>
                <a href="#contact" className="mt-10 inline-flex items-center gap-1.5 text-sm font-medium text-foreground">
                  Get a proposal
                  <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
                <div className="absolute bottom-0 left-0 h-0.5 w-0 bg-accent transition-all duration-500 group-hover:w-full" />
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Stats() {
  return (
    <section id="work" className="relative border-b border-border bg-foreground text-background">
      <div className="container-x grid grid-cols-2 gap-8 py-20 md:grid-cols-4 md:py-24">
        {stats.map((s) => (
          <div key={s.label}>
            <div className="text-5xl font-semibold tracking-tight md:text-6xl">
              {s.value}
              <span className="text-accent">.</span>
            </div>
            <div className="mt-2 font-mono text-xs uppercase tracking-widest text-background/60">{s.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function Process() {
  return (
    <section id="process" className="border-b border-border py-24 md:py-32">
      <div className="container-x">
        <div className="mb-16 max-w-3xl">
          <div className="mb-4 font-mono text-xs uppercase tracking-widest text-accent">— Process</div>
          <h2 className="text-balance text-4xl font-semibold tracking-tight md:text-5xl">
            A tight loop from idea to impact.
          </h2>
        </div>
        <div className="grid gap-6 md:grid-cols-4">
          {process.map((p, i) => (
            <div key={p.step} className="group relative border-t-2 border-foreground pt-6">
              <div className="absolute -top-[5px] left-0 h-2 w-12 bg-accent transition-all duration-500 group-hover:w-24" />
              <div className="font-mono text-xs text-muted-foreground">0{i + 1}</div>
              <h3 className="mt-3 text-xl font-semibold">{p.step}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section id="contact" className="relative overflow-hidden border-b border-border bg-card py-24 md:py-32">
      <div className="absolute inset-0 grid-bg opacity-50" aria-hidden />
      <div className="container-x relative">
        <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <div className="mb-4 font-mono text-xs uppercase tracking-widest text-accent">— Let's build</div>
            <h2 className="text-balance text-5xl font-semibold leading-[1] tracking-tight md:text-7xl">
              Your next system,<br />
              shipped<span className="text-accent">.</span>
            </h2>
            <p className="mt-6 max-w-lg text-muted-foreground">
              Tell us about the product, the problem, or the pipeline. We respond within one business day
              with a concrete next step.
            </p>
          </div>
          <div className="lg:col-span-5">
            <div className="rounded-sm border border-border bg-background p-6 shadow-[var(--shadow-soft)]">
              <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Contact</div>
              <a href="mailto:info@cogniloop.digital?subject=New%20Project%20Inquiry%20-%20%5BYour%20Name%20%2F%20Your%20Company%20Name%20%2F%20Project%20Name%5D&body=Hi%20Team%2C%0AI%E2%80%99m%20reaching%20out%20to%20discuss%20a%20potential%20project%20with%20your%20team." className="mt-2 block text-2xl font-semibold hover:text-accent">
                info@cogniloop.digital
              </a>
              <div className="my-6 h-px bg-border" />
              <a
                href="mailto:info@cogniloop.digital?subject=New%20Project%20Inquiry%20-%20%5BYour%20Name%20%2F%20Your%20Company%20Name%20%2F%20Project%20Name%5D&body=Hi%20Team%2C%0AI%E2%80%99m%20reaching%20out%20to%20discuss%20a%20potential%20project%20with%20your%20team."
                className="group flex items-center justify-between rounded-sm bg-accent px-5 py-4 text-sm font-medium text-accent-foreground shadow-[var(--shadow-red)]"
              >
                Start a project
                <ArrowUpRight className="h-4 w-4 transition-transform group-hover:rotate-45" />
              </a>
              <div className="mt-6 grid grid-cols-2 gap-4 font-mono text-xs text-muted-foreground">
                <div>
                  <div className="text-foreground">HQ</div>
                  Pakistan
                </div>
                <div>
                  <div className="text-foreground">Response</div>
                  &lt; 24h
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-background py-12">
      <div className="container-x flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
        <Logo />
        <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          © {new Date().getFullYear()} Cogniloop. All rights reserved.
        </div>
        <div className="flex gap-4 text-sm text-muted-foreground">
          <a href="https://www.linkedin.com/company/cogniloop" target="_blank" rel="noopener noreferrer" className="hover:text-foreground">LinkedIn</a>
          <a href="https://www.facebook.com/share/18rLrh1s58/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground">Facebook</a>
          <a href="https://www.instagram.com/cogniloop.digital/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground">Instagram</a>
        </div>
      </div>
    </footer>
  );
}
